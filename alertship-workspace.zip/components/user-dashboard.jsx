"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Bell, MapPin, Calendar, AlertTriangle, X, Settings } from "lucide-react"

export default function UserDashboard({ user, onLogout }) {
  const [activeTab, setActiveTab] = useState("overview")
  const [showAddLocationModal, setShowAddLocationModal] = useState(false)
  const [newLocation, setNewLocation] = useState({ name: "", address: "" })
  const [notificationSettings, setNotificationSettings] = useState({
    browser: true,
    whatsapp: true,
    email: false,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showReportModal, setShowReportModal] = useState(false)
  const [showNotificationModal, setShowNotificationModal] = useState(false)
  const [editingLocationId, setEditingLocationId] = useState(null)
  const [locationSuccessMessage, setLocationSuccessMessage] = useState("")

  const [showChangeNumberModal, setShowChangeNumberModal] = useState(false)
  const [newWhatsAppNumber, setNewWhatsAppNumber] = useState("")
  const [showWhatsAppOtp, setShowWhatsAppOtp] = useState(false)
  const [whatsappOtp, setWhatsappOtp] = useState("")
  const [generatedWhatsappOtp, setGeneratedWhatsappOtp] = useState("")
  const [isVerifyingWhatsApp, setIsVerifyingWhatsApp] = useState(false)
  const [whatsappVerified, setWhatsappVerified] = useState(false)
  const [resendTimer, setResendTimer] = useState(0)
  const [changeNumberErrors, setChangeNumberErrors] = useState({})
  const [otpSuccessMessage, setOtpSuccessMessage] = useState("")
  const [showCalendarModal, setShowCalendarModal] = useState(false)
  const [showCalendarPage, setShowCalendarPage] = useState(false)

  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [locationToDelete, setLocationToDelete] = useState(null)

  const [profileSuccessMessage, setProfileSuccessMessage] = useState("")

  const [currentDate, setCurrentDate] = useState(new Date(2023, 5, 1))

  // Mock data for the dashboard
  const recentReports = [
    {
      id: 1,
      type: "electricity",
      location: "Sector 15, Block A",
      date: "2023-06-01",
      status: "resolved",
      description: "Power outage due to transformer failure",
      source: "official",
    },
    {
      id: 2,
      type: "water",
      location: "Phase 2, Main Road",
      date: "2023-05-28",
      status: "pending",
      description: "Low water pressure in the morning",
      source: "crowdsourced",
    },
  ]

  const upcomingOutages = [
    {
      id: 1,
      type: "electricity",
      location: "Sector 15",
      date: "2023-06-15",
      time: "10:00 AM - 2:00 PM",
      description: "Scheduled maintenance of electrical lines",
    },
    {
      id: 2,
      type: "water",
      location: "Phase 2",
      date: "2023-06-21",
      time: "8:00 AM - 12:00 PM",
      description: "Pipeline cleaning and pressure testing",
    },
  ]

  const [savedLocations, setSavedLocations] = useState([
    {
      id: 1,
      name: "Home",
      address: "123 Main Street, Sector 15",
    },
    {
      id: 2,
      name: "Office",
      address: "456 Business Park, Phase 2",
    },
  ])

  const [showReportPage, setShowReportPage] = useState(false)
  const [showOutagesPage, setShowOutagesPage] = useState(false)
  const [expandedReportId, setExpandedReportId] = useState(null)
  const [expandedOutageId, setExpandedOutageId] = useState(null)
  const [showOutageDetailsModal, setShowOutageDetailsModal] = useState(false)
  const [selectedOutageDetails, setSelectedOutageDetails] = useState(null)

  const [reportFilters, setReportFilters] = useState({
    type: "all",
  })

  const [reportForm, setReportForm] = useState({
    type: "electricity",
    description: "",
    address: "",
    locality: "",
    city: "",
    state: "",
    pinCode: "",
    photo: null,
    name: "",
    contact: "",
  })

  // Calendar Page
  if (showCalendarPage) {
    return (
      <div className="bg-[#F9FAFB] min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-[#1F2937]">Upcoming Outages Calendar</h1>
                <p className="text-gray-600 mt-1">View scheduled outages and maintenance in your area</p>
              </div>
              <Button
                onClick={() => setShowCalendarPage(false)}
                variant="outline"
                className="border-[#1F2937] text-[#1F2937] hover:bg-[#1F2937] hover:text-white flex items-center"
              >
                ← Back to Dashboard
              </Button>
            </div>
          </div>

          {/* Calendar Content */}
          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="p-6">
              <div className="space-y-6">
                {/* Calendar Header */}
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-[#1F2937]">
                    {currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                  </h3>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newDate = new Date(currentDate)
                        newDate.setMonth(currentDate.getMonth() - 1)
                        setCurrentDate(newDate)
                      }}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newDate = new Date(currentDate)
                        newDate.setMonth(currentDate.getMonth() + 1)
                        setCurrentDate(newDate)
                      }}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </Button>
                  </div>
                </div>

                {/* Calendar Grid */}
                <div className="grid grid-cols-7 gap-2">
                  {/* Day headers */}
                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                    <div key={day} className="p-2 text-center text-sm font-medium text-gray-500">
                      {day}
                    </div>
                  ))}

                  {/* Calendar days */}
                  {(() => {
                    const year = currentDate.getFullYear()
                    const month = currentDate.getMonth()
                    const firstDay = new Date(year, month, 1)
                    const startDate = new Date(firstDay)
                    startDate.setDate(startDate.getDate() - firstDay.getDay())

                    const days = []
                    const currentDateObj = new Date(startDate)

                    for (let i = 0; i < 42; i++) {
                      const day = currentDateObj.getDate()
                      const isCurrentMonth = currentDateObj.getMonth() === month
                      const isToday = currentDateObj.toDateString() === new Date().toDateString()

                      const hasOutage =
                        isCurrentMonth &&
                        ((month === 5 && year === 2023 && [15, 21].includes(day)) ||
                          (month === 4 && year === 2023 && [10, 25].includes(day)) ||
                          (month === 6 && year === 2023 && [5, 18].includes(day)))

                      days.push(
                        <div
                          key={i}
                          className={`p-2 h-16 border rounded-lg ${
                            isCurrentMonth ? "bg-white" : "bg-gray-50"
                          } ${hasOutage ? "border-red-300 bg-red-50" : "border-gray-200"} ${
                            isToday ? "ring-2 ring-blue-500" : ""
                          }`}
                        >
                          <div
                            className={`text-sm ${
                              isCurrentMonth ? "text-gray-900" : "text-gray-400"
                            } ${isToday ? "font-bold text-blue-600" : ""}`}
                          >
                            {day}
                          </div>
                          {hasOutage && (
                            <div className="mt-1">
                              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                            </div>
                          )}
                        </div>,
                      )

                      currentDateObj.setDate(currentDateObj.getDate() + 1)
                    }

                    return days
                  })()}
                </div>

                {/* Outage Details */}
                <div className="border-t pt-6">
                  <h4 className="font-semibold text-[#1F2937] mb-4">
                    Scheduled Outages for {currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                  </h4>
                  <div className="space-y-3">
                    {(() => {
                      const month = currentDate.getMonth()
                      const year = currentDate.getFullYear()

                      let monthlyOutages = []

                      if (month === 5 && year === 2023) {
                        monthlyOutages = upcomingOutages.map((outage) => ({
                          ...outage,
                          source: outage.id === 1 ? "official" : "crowdsourced",
                        }))
                      } else if (month === 4 && year === 2023) {
                        monthlyOutages = [
                          {
                            id: 1,
                            type: "water",
                            location: "Sector 12",
                            date: "2023-05-10",
                            time: "9:00 AM - 1:00 PM",
                            description: "Water tank cleaning and maintenance",
                            source: "official",
                          },
                          {
                            id: 2,
                            type: "electricity",
                            location: "Phase 1",
                            date: "2023-05-25",
                            time: "6:00 AM - 10:00 AM",
                            description: "Power grid upgrade work",
                            source: "official",
                          },
                        ]
                      } else if (month === 6 && year === 2023) {
                        monthlyOutages = [
                          {
                            id: 1,
                            type: "electricity",
                            location: "Sector 20",
                            date: "2023-07-05",
                            time: "11:00 AM - 3:00 PM",
                            description: "Transformer replacement work",
                            source: "official",
                          },
                          {
                            id: 2,
                            type: "water",
                            location: "Phase 3",
                            date: "2023-07-18",
                            time: "7:00 AM - 11:00 AM",
                            description: "Pipeline repair and testing",
                            source: "crowdsourced",
                          },
                        ]
                      }

                      if (monthlyOutages.length === 0) {
                        return (
                          <div className="text-center py-8">
                            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                              <svg
                                className="w-6 h-6 text-green-600"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                            </div>
                            <p className="text-gray-600">No scheduled outages for this month</p>
                          </div>
                        )
                      }

                      return monthlyOutages.map((outage) => (
                        <div key={outage.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center ${
                              outage.type === "electricity" ? "bg-[#F59E0B]/20" : "bg-[#4F46E5]/20"
                            }`}
                          >
                            <Calendar
                              className={`w-4 h-4 ${outage.type === "electricity" ? "text-[#F59E0B]" : "text-[#4F46E5]"}`}
                            />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <h5 className="font-medium">{outage.location}</h5>
                                <span
                                  className={`text-xs px-2 py-1 rounded font-medium ${
                                    outage.source === "official"
                                      ? "bg-green-100 text-green-700"
                                      : "bg-blue-100 text-blue-700"
                                  }`}
                                >
                                  {outage.source === "official" ? "Official" : "Crowdsourced"}
                                </span>
                              </div>
                              <span className="text-xs text-gray-500">{outage.date}</span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">{outage.description}</p>
                            <p className="text-xs text-gray-500 mt-1">Time: {outage.time}</p>
                          </div>
                        </div>
                      ))
                    })()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Outages Page
  if (showOutagesPage) {
    const handleViewOutageDetails = (outageId) => {
      const outageDetails = {
        id: outageId,
        title: "Power Outage - Sector 15",
        type: "electricity",
        status: "active",
        priority: "high",
        location: "Sector 15, Block A",
        affectedHouseholds: 150,
        cause: "Transformer failure in main distribution grid",
        crewStatus: "On-site working",
        estimatedRestoration: "2-4 hours",
        reportedAt: "Today at 1:25 PM",
        lastUpdate: "35 minutes ago",
        description:
          "Complete power failure reported in residential area. Maintenance team dispatched to replace faulty transformer unit.",
        timeline: [
          { time: "1:25 PM", event: "Outage Reported", status: "completed" },
          { time: "1:45 PM", event: "Crew Dispatched", status: "completed" },
          { time: "2:00 PM", event: "Work in Progress", status: "current" },
          { time: "4:00 PM", event: "Estimated Restoration", status: "pending" },
        ],
        technicalDetails:
          "Transformer T-15A in the main distribution grid requires replacement due to overheating. The maintenance crew is currently installing a new transformer unit. Power will be restored once the installation is complete and safety checks are performed.",
        safetyNotice:
          "Please avoid using high-power appliances immediately after power restoration to prevent voltage fluctuations.",
      }

      setSelectedOutageDetails(outageDetails)
      setShowOutageDetailsModal(true)
    }

    return (
      <div className="bg-[#F9FAFB] min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-[#1F2937]">Current Outages</h1>
                <p className="text-gray-600 mt-1">View active outages in your saved locations</p>
              </div>
              <Button
                onClick={() => setShowOutagesPage(false)}
                variant="outline"
                className="border-[#1F2937] text-[#1F2937] hover:bg-[#1F2937] hover:text-white flex items-center"
              >
                ← Back to Dashboard
              </Button>
            </div>
          </div>

          {/* Outages Content */}
          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="p-6">
              <div className="space-y-6">
                {savedLocations.map((location) => (
                  <div key={location.id} className="border-b pb-6 last:border-b-0 last:pb-0">
                    <div className="flex items-center mb-4">
                      <div className="w-10 h-10 bg-[#4F46E5]/10 rounded-full flex items-center justify-center mr-3">
                        <MapPin className="w-5 h-5 text-[#4F46E5]" />
                      </div>
                      <h3 className="text-lg font-semibold text-[#1F2937]">{location.name}</h3>
                    </div>

                    {location.id === 1 ? (
                      <div className="space-y-3">
                        <div className="flex items-start space-x-3 p-3 bg-red-50 rounded-lg border border-red-100">
                          <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                            <AlertTriangle className="w-4 h-4 text-red-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium text-[#1F2937]">Power Outage</h4>
                                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded font-medium">
                                  Official
                                </span>
                              </div>
                              <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Active</span>
                            </div>
                            <p className="text-sm text-gray-600 mt-1">
                              Electrical grid maintenance affecting multiple blocks in this area.
                            </p>
                            <div className="flex justify-between items-center mt-2">
                              <p className="text-xs text-gray-500">Reported 35 minutes ago</p>
                              <p className="text-xs font-medium text-gray-700">Est. resolution: 2 hours</p>
                            </div>
                            <div className="mt-3">
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-xs border-red-300 text-red-700 hover:bg-red-100"
                                onClick={() => handleViewOutageDetails(location.id)}
                              >
                                View Details
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 bg-green-50 rounded-lg border border-green-100">
                        <div className="flex items-center">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                            <svg
                              className="w-4 h-4 text-green-600"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                          </div>
                          <div>
                            <p className="font-medium text-green-800">No active outages reported</p>
                            <p className="text-sm text-green-600">
                              All utilities are functioning normally in this area
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Outage Details Modal */}
          {showOutageDetailsModal && selectedOutageDetails && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
                <div className="p-6 border-b">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold text-[#1F2937]">{selectedOutageDetails.title}</h2>
                      <div className="flex items-center gap-2 mt-2">
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            selectedOutageDetails.status === "active"
                              ? "bg-red-100 text-red-700"
                              : "bg-green-100 text-green-700"
                          }`}
                        >
                          {selectedOutageDetails.status === "active" ? "Active" : "Resolved"}
                        </span>
                        <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded font-medium">
                          Official
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowOutageDetailsModal(false)}
                      className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                    >
                      <X className="w-6 h-6 text-gray-500" />
                    </button>
                  </div>
                </div>

                <div className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold text-[#1F2937] mb-3">Outage Information</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Outage ID:</span>
                            <span className="font-medium">#{selectedOutageDetails.id.toString().padStart(6, "0")}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Type:</span>
                            <span className="font-medium capitalize">{selectedOutageDetails.type}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Priority:</span>
                            <span className="font-medium capitalize">{selectedOutageDetails.priority}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Affected Households:</span>
                            <span className="font-medium">~{selectedOutageDetails.affectedHouseholds} homes</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Crew Status:</span>
                            <span className="font-medium">{selectedOutageDetails.crewStatus}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Est. Restoration:</span>
                            <span className="font-medium">{selectedOutageDetails.estimatedRestoration}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-semibold text-[#1F2937] mb-3">Description</h3>
                        <p className="text-gray-600 leading-relaxed">{selectedOutageDetails.description}</p>
                      </div>

                      <div>
                        <h3 className="font-semibold text-[#1F2937] mb-3">Technical Details</h3>
                        <p className="text-gray-600 leading-relaxed">{selectedOutageDetails.technicalDetails}</p>
                      </div>

                      {selectedOutageDetails.safetyNotice && (
                        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                          <div className="flex items-start">
                            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3 mt-0.5 flex-shrink-0" />
                            <div>
                              <h4 className="font-medium text-yellow-800 mb-1">Safety Notice</h4>
                              <p className="text-sm text-yellow-700">{selectedOutageDetails.safetyNotice}</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div>
                      <h3 className="font-semibold text-[#1F2937] mb-4">Timeline</h3>
                      <div className="space-y-4">
                        {selectedOutageDetails.timeline.map((item, index) => (
                          <div key={index} className="flex items-start space-x-3">
                            <div
                              className={`w-3 h-3 rounded-full mt-2 ${
                                item.status === "completed"
                                  ? "bg-green-500"
                                  : item.status === "current"
                                    ? "bg-blue-500"
                                    : "bg-gray-300"
                              }`}
                            ></div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h4
                                  className={`font-medium ${
                                    item.status === "current" ? "text-blue-700" : "text-[#1F2937]"
                                  }`}
                                >
                                  {item.event}
                                </h4>
                                <span className="text-sm text-gray-500">{item.time}</span>
                              </div>
                              {item.status === "current" && (
                                <p className="text-sm text-blue-600 mt-1">In progress...</p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  // Report Page
  if (showReportPage) {
    return (
      <div className="bg-[#F9FAFB] min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-[#1F2937]">Report New Outage</h1>
                <p className="text-gray-600 mt-1">Report electricity or water outages in your area</p>
              </div>
              <Button
                onClick={() => setShowReportPage(false)}
                variant="outline"
                className="border-[#1F2937] text-[#1F2937] hover:bg-[#1F2937] hover:text-white flex items-center"
              >
                ← Back to Dashboard
              </Button>
            </div>
          </div>

          {/* Report Form */}
          <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
            <div className="p-6">
              <form className="space-y-6">
                {/* Outage Type */}
                <div>
                  <label className="block text-sm font-medium text-[#1F2937] mb-3">Outage Type</label>
                  <div className="grid grid-cols-2 gap-4">
                    <div
                      className={`border-2 ${
                        reportForm.type === "electricity"
                          ? "border-[#F59E0B] bg-[#F59E0B]/10"
                          : "border-gray-200 hover:border-gray-300"
                      } rounded-lg p-4 cursor-pointer transition-colors`}
                      onClick={() => setReportForm((prev) => ({ ...prev, type: "electricity" }))}
                    >
                      <div className="flex items-center">
                        <div
                          className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
                            reportForm.type === "electricity" ? "border-[#F59E0B]" : "border-gray-400"
                          }`}
                        >
                          {reportForm.type === "electricity" && <div className="w-3 h-3 rounded-full bg-[#F59E0B]" />}
                        </div>
                        <div className="flex items-center">
                          <AlertTriangle className="w-5 h-5 mr-2 text-gray-700" />
                          <div>
                            <p className="font-medium">Electricity</p>
                            <p className="text-xs text-gray-500">Power outage or issues</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-colors ${
                        reportForm.type === "water"
                          ? "border-[#4F46E5] bg-[#4F46E5]/10"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                      onClick={() => setReportForm((prev) => ({ ...prev, type: "water" }))}
                    >
                      <div className="flex items-center">
                        <div
                          className={`w-5 h-5 rounded-full border-2 mr-3 flex items-center justify-center ${
                            reportForm.type === "water" ? "border-[#4F46E5]" : "border-gray-400"
                          }`}
                        >
                          {reportForm.type === "water" && <div className="w-3 h-3 rounded-full bg-[#4F46E5]" />}
                        </div>
                        <div className="flex items-center">
                          <svg className="w-5 h-5 mr-2 text-gray-700" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                              clipRule="evenodd"
                            />
                          </svg>
                          <div>
                            <p className="font-medium">Water</p>
                            <p className="text-xs text-gray-500">Water supply issues</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-[#1F2937] mb-2">
                    Description <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="description"
                    placeholder="Please describe the issue in detail"
                    className="w-full min-h-[100px] p-3 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none rounded-md"
                  />
                </div>

                {/* Location Details */}
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-medium text-[#1F2937] mb-4">Location Details</h3>

                  {/* Address */}
                  <div className="mb-4">
                    <label htmlFor="address" className="block text-sm font-medium text-[#1F2937] mb-2">
                      Specific Address/Location <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                      <Input
                        id="address"
                        placeholder="Enter specific location of the issue"
                        className="pl-10 h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Locality */}
                    <div>
                      <label htmlFor="locality" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Locality <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="locality"
                        placeholder="e.g. Sector 150, Villaspur"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>

                    {/* City */}
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-[#1F2937] mb-2">
                        City <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="city"
                        placeholder="e.g. Noida"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>

                    {/* State */}
                    <div>
                      <label htmlFor="state" className="block text-sm font-medium text-[#1F2937] mb-2">
                        State <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="state"
                        placeholder="Enter state name"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>

                    {/* Pin Code */}
                    <div>
                      <label htmlFor="pinCode" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Pin Code <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="pinCode"
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength="6"
                        placeholder="Enter 6-digit pin code"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Photo Upload */}
                <div>
                  <label className="block text-sm font-medium text-[#1F2937] mb-2">Upload Photo (Optional)</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <input type="file" id="photo" accept="image/*" className="hidden" />
                    <label htmlFor="photo" className="cursor-pointer">
                      <div className="flex flex-col items-center">
                        <svg
                          className="w-10 h-10 text-gray-400 mb-2"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                          />
                        </svg>
                        <p className="text-sm text-gray-600">Click to upload a photo of the issue</p>
                        <p className="text-xs text-gray-500 mt-1">PNG, JPG, GIF up to 10MB</p>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Contact Information */}
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-medium text-[#1F2937] mb-4">Your Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Your Name <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="name"
                        placeholder="Enter your full name"
                        defaultValue={user.name}
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>

                    <div>
                      <label htmlFor="contact" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Email or Phone <span className="text-red-500">*</span>
                      </label>
                      <Input
                        id="contact"
                        placeholder="Enter your email or phone number"
                        defaultValue={user.email}
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex justify-end gap-3 pt-6 border-t border-gray-200">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowReportPage(false)}
                    className="border-gray-300"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    onClick={(e) => {
                      e.preventDefault()
                      setShowReportPage(false)
                      alert("Report submitted successfully! You will receive updates on the status.")
                    }}
                    className="bg-[#F59E0B] hover:bg-[#F59E0B]/90 text-white px-8"
                  >
                    Submit Report
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Helper functions
  const handleAddLocation = (e) => {
    e.preventDefault()

    if (editingLocationId) {
      const locationIndex = savedLocations.findIndex((loc) => loc.id === editingLocationId)
      if (locationIndex !== -1) {
        const updatedLocations = [...savedLocations]
        updatedLocations[locationIndex] = {
          ...updatedLocations[locationIndex],
          name: newLocation.name,
          address: newLocation.address,
        }
        setSavedLocations(updatedLocations)
        console.log("Location updated:", updatedLocations[locationIndex])
        setLocationSuccessMessage(`Location "${newLocation.name}" updated successfully!`)
      }
      setEditingLocationId(null)
    } else {
      const newLocationItem = {
        id: savedLocations.length > 0 ? Math.max(...savedLocations.map((loc) => loc.id)) + 1 : 1,
        name: newLocation.name,
        address: newLocation.address,
      }
      setSavedLocations([...savedLocations, newLocationItem])
      console.log("Location added:", newLocationItem)
      setLocationSuccessMessage(`Location "${newLocation.name}" added successfully!`)
    }

    setNewLocation({ name: "", address: "" })
    setShowAddLocationModal(false)

    setTimeout(() => {
      setLocationSuccessMessage("")
    }, 3000)
  }

  const handleToggleNotification = (type) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [type]: !prev[type],
    }))
  }

  const handleSaveNotificationSettings = async () => {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log("Notification settings saved:", notificationSettings)
      alert("Notification settings saved successfully!")
    } catch (error) {
      console.error("Error saving settings:", error)
      alert("Failed to save settings. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleReportNewOutage = () => {
    setShowReportPage(true)
  }

  const handleViewDetails = (reportId) => {
    setExpandedReportId(expandedReportId === reportId ? null : reportId)
  }

  const handleViewOutages = (locationId) => {
    console.log("Viewing outages for location:", locationId)
    alert(`Viewing outages for location ${locationId}`)
  }

  const handleSetAsDefault = (locationId) => {
    console.log("Setting location as default:", locationId)
    alert(`Location ${locationId} set as default`)
  }

  const handleEditLocation = (locationId) => {
    const locationToEdit = savedLocations.find((loc) => loc.id === locationId)
    if (locationToEdit) {
      setNewLocation({ name: locationToEdit.name, address: locationToEdit.address })
      setEditingLocationId(locationId)
      setShowAddLocationModal(true)
    }
  }

  const handleDeleteLocation = (locationId) => {
    const locationToDelete = savedLocations.find((loc) => loc.id === locationId)
    setLocationToDelete(locationToDelete)
    setShowDeleteModal(true)
  }

  const confirmDeleteLocation = () => {
    if (locationToDelete) {
      const updatedLocations = savedLocations.filter((loc) => loc.id !== locationToDelete.id)
      setSavedLocations(updatedLocations)
      console.log("Deleting location:", locationToDelete.id)
      setLocationSuccessMessage(`Location "${locationToDelete.name}" deleted successfully!`)

      setTimeout(() => {
        setLocationSuccessMessage("")
      }, 3000)
    }
    setShowDeleteModal(false)
    setLocationToDelete(null)
  }

  const handleUpdateProfile = async () => {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setProfileSuccessMessage("Profile updated successfully!")

      setTimeout(() => {
        setProfileSuccessMessage("")
      }, 5000)
    } catch (error) {
      alert("Failed to update profile. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleChangePassword = async () => {
    setIsSubmitting(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      alert("Password changed successfully!")
    } catch (error) {
      alert("Failed to change password. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteAccount = () => {
    if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      console.log("Deleting account")
      alert("Account deletion initiated. You will be contacted for confirmation.")
    }
  }

  const generateOtp = () => {
    return Math.floor(100000 + Math.random() * 900000).toString()
  }

  const startResendTimer = () => {
    setResendTimer(60)
    const timer = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }

  const sendWhatsAppOtp = async (phoneNumber) => {
    const newOtp = generateOtp()
    setGeneratedWhatsappOtp(newOtp)
    setIsVerifyingWhatsApp(true)
    setOtpSuccessMessage("")

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      console.log(`WhatsApp OTP sent to ${phoneNumber}: ${newOtp}`)

      setOtpSuccessMessage("OTP Sent Successfully")

      setShowWhatsAppOtp(true)
      startResendTimer()

      setTimeout(() => {
        setOtpSuccessMessage("")
      }, 5000)
    } catch (error) {
      console.error("Error sending WhatsApp OTP:", error)
      setChangeNumberErrors({ whatsapp: "Failed to send OTP. Please try again." })
    } finally {
      setIsVerifyingWhatsApp(false)
    }
  }

  const verifyWhatsAppOtp = async () => {
    if (!whatsappOtp.trim()) {
      setChangeNumberErrors({ whatsappOtp: "OTP is required" })
      return
    }
    if (whatsappOtp.length !== 6) {
      setChangeNumberErrors({ whatsappOtp: "OTP must be 6 digits" })
      return
    }
    if (whatsappOtp !== generatedWhatsappOtp) {
      setChangeNumberErrors({ whatsappOtp: "Invalid OTP. Please try again." })
      return
    }

    setIsVerifyingWhatsApp(true)
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setWhatsappVerified(true)
      setShowWhatsAppOtp(false)
      setShowChangeNumberModal(false)
      setChangeNumberErrors({})

      setNewWhatsAppNumber("")
      setWhatsappOtp("")
      setGeneratedWhatsappOtp("")
      setResendTimer(0)

      alert("WhatsApp number changed and verified successfully!")
    } catch (error) {
      setChangeNumberErrors({ whatsappOtp: "Verification failed. Please try again." })
    } finally {
      setIsVerifyingWhatsApp(false)
    }
  }

  const resendWhatsAppOtp = async () => {
    if (resendTimer > 0) return
    await sendWhatsAppOtp(newWhatsAppNumber)
  }

  const handleChangeWhatsAppNumber = () => {
    setShowChangeNumberModal(true)
    setNewWhatsAppNumber("")
    setChangeNumberErrors({})
  }

  const handleSubmitNewNumber = async (e) => {
    e.preventDefault()

    if (!newWhatsAppNumber.trim()) {
      setChangeNumberErrors({ phone: "Phone number is required" })
      return
    }

    if (!/^\+?[0-9]{10,15}$/.test(newWhatsAppNumber.replace(/\s/g, ""))) {
      setChangeNumberErrors({ phone: "Please enter a valid phone number" })
      return
    }

    setChangeNumberErrors({})
    await sendWhatsAppOtp(newWhatsAppNumber)
  }

  // Main dashboard render
  return (
    <div className="bg-[#F9FAFB] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-[#1F2937]">Welcome, {user.name}</h1>
              <p className="text-gray-600 mt-1">Stay updated with outages in your area</p>
            </div>
          </div>
        </div>

        {/* Dashboard Tabs */}
        <div className="bg-white rounded-2xl shadow-sm border overflow-hidden mb-6">
          <div className="border-b">
            <div className="flex overflow-x-auto">
              <button
                onClick={() => setActiveTab("overview")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap ${
                  activeTab === "overview"
                    ? "border-b-2 border-[#4F46E5] text-[#4F46E5]"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab("reports")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap ${
                  activeTab === "reports"
                    ? "border-b-2 border-[#4F46E5] text-[#4F46E5]"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                My Reports
              </button>
              <button
                onClick={() => setActiveTab("locations")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap ${
                  activeTab === "locations"
                    ? "border-b-2 border-[#4F46E5] text-[#4F46E5]"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Saved Locations
              </button>
              <button
                onClick={() => setActiveTab("notifications")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap ${
                  activeTab === "notifications"
                    ? "border-b-2 border-[#4F46E5] text-[#4F46E5]"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Notification Settings
              </button>
              <button
                onClick={() => setActiveTab("account")}
                className={`px-4 py-3 font-medium text-sm whitespace-nowrap ${
                  activeTab === "account"
                    ? "border-b-2 border-[#4F46E5] text-[#4F46E5]"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Account Settings
              </button>
            </div>
          </div>

          <div className="p-6">
            {/* Overview Tab */}
            {activeTab === "overview" && (
              <div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  {/* Recent Reports Summary */}
                  <div className="border rounded-xl p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-[#1F2937]">Your Recent Reports</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#4F46E5] hover:bg-[#4F46E5]/10"
                        onClick={() => setActiveTab("reports")}
                      >
                        View All
                      </Button>
                    </div>
                    {recentReports.length > 0 ? (
                      <div className="space-y-3">
                        {recentReports.slice(0, 2).map((report) => (
                          <div key={report.id} className="flex items-start space-x-3">
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                report.type === "electricity" ? "bg-[#F59E0B]/20" : "bg-[#4F46E5]/20"
                              }`}
                            >
                              {report.type === "electricity" ? (
                                <Bell className={`w-4 h-4 text-[#F59E0B]`} />
                              ) : (
                                <Bell className={`w-4 h-4 text-[#4F46E5]`} />
                              )}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <p className="font-medium text-sm">{report.location}</p>
                                  <span
                                    className={`text-xs px-1.5 py-0.5 rounded font-medium bg-blue-100 text-blue-700`}
                                  >
                                    User Report
                                  </span>
                                </div>
                                <span
                                  className={`text-xs px-2 py-1 rounded-full ${
                                    report.status === "resolved"
                                      ? "bg-green-100 text-green-800"
                                      : "bg-yellow-100 text-yellow-800"
                                  }`}
                                >
                                  {report.status === "resolved" ? "Resolved" : "Pending"}
                                </span>
                              </div>
                              <p className="text-xs text-gray-500 mt-1">{report.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">You haven't reported any outages yet.</p>
                    )}
                  </div>

                  {/* Upcoming Outages Summary */}
                  <div className="border rounded-xl p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-[#1F2937]">Upcoming Outages</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#4F46E5] hover:bg-[#4F46E5]/10"
                        onClick={() => setShowCalendarPage(true)}
                      >
                        View Calendar
                      </Button>
                    </div>
                    {upcomingOutages.length > 0 ? (
                      <div className="space-y-3">
                        {upcomingOutages.map((outage) => (
                          <div key={outage.id} className="flex items-start space-x-3">
                            <div
                              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                outage.type === "electricity" ? "bg-[#F59E0B]/20" : "bg-[#4F46E5]/20"
                              }`}
                            >
                              <Calendar
                                className={`w-4 h-4 ${
                                  outage.type === "electricity" ? "text-[#F59E0B]" : "text-[#4F46E5]"
                                }`}
                              />
                            </div>
                            <div>
                              <div className="flex items-center gap-1">
                                <p className="font-medium text-sm">{outage.location}</p>
                                <span
                                  className={`text-xs px-1.5 py-0.5 rounded-full ${
                                    outage.type === "electricity"
                                      ? "bg-amber-100 text-amber-700"
                                      : "bg-indigo-100 text-indigo-700"
                                  }`}
                                >
                                  {outage.type === "electricity" ? "Electricity" : "Water"}
                                </span>
                              </div>
                              <p className="text-xs text-gray-500">
                                {outage.date} • {outage.time}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">No upcoming scheduled outages in your area.</p>
                    )}
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="border rounded-xl p-4">
                  <h3 className="font-semibold text-[#1F2937] mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                    <Button
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center border-gray-300 hover:border-[#4F46E5] hover:text-[#4F46E5]"
                      onClick={() => setShowOutagesPage(true)}
                    >
                      <MapPin className="w-5 h-5 mb-2" />
                      <span className="text-xs">Check Outages</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center border-gray-300 hover:border-[#4F46E5] hover:text-[#4F46E5]"
                      onClick={handleReportNewOutage}
                    >
                      <AlertTriangle className="w-5 h-5 mb-2" />
                      <span className="text-xs">Report Outage</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center border-gray-300 hover:border-[#4F46E5] hover:text-[#4F46E5]"
                      onClick={() => setShowAddLocationModal(true)}
                    >
                      <MapPin className="w-5 h-5 mb-2" />
                      <span className="text-xs">Add Location</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center border-gray-300 hover:border-[#4F46E5] hover:text-[#4F46E5]"
                      onClick={() => setActiveTab("notifications")}
                    >
                      <Bell className="w-5 h-5 mb-2" />
                      <span className="text-xs">Manage Alerts</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-auto py-4 flex flex-col items-center justify-center border-gray-300 hover:border-[#4F46E5] hover:text-[#4F46E5]"
                      onClick={() => setActiveTab("account")}
                    >
                      <Settings className="w-5 h-5 mb-2" />
                      <span className="text-xs">Settings</span>
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {/* Reports Tab */}
            {activeTab === "reports" && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-[#1F2937]">My Reported Outages</h2>
                  <Button variant="outline" onClick={handleReportNewOutage}>
                    Report New Outage
                  </Button>
                </div>

                {/* Report Filters */}
                <div className="flex items-center space-x-4 mb-4">
                  <label htmlFor="typeFilter" className="text-sm font-medium text-gray-700">
                    Filter by Type:
                  </label>
                  <select
                    id="typeFilter"
                    className="border border-gray-300 rounded-md p-2 text-sm"
                    value={reportFilters.type}
                    onChange={(e) => setReportFilters({ ...reportFilters, type: e.target.value })}
                  >
                    <option value="all">All</option>
                    <option value="electricity">Electricity</option>
                    <option value="water">Water</option>
                  </select>
                </div>

                {/* Report List */}
                <div className="space-y-4">
                  {recentReports
                    .filter((report) => reportFilters.type === "all" || report.type === reportFilters.type)
                    .map((report) => (
                      <div key={report.id} className="border rounded-md p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-lg font-medium text-[#1F2937]">
                            {report.type === "electricity" ? "Electricity Outage" : "Water Issue"}
                          </h3>
                          <span
                            className={`text-xs px-2 py-1 rounded-full ${
                              report.status === "resolved"
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {report.status === "resolved" ? "Resolved" : "Pending"}
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">Location: {report.location}</p>
                        <p className="text-gray-600 text-sm mb-2">Reported on: {report.date}</p>
                        <p className="text-gray-600 text-sm mb-2">Description: {report.description}</p>
                        <Button variant="outline" size="sm" onClick={() => handleViewDetails(report.id)}>
                          {expandedReportId === report.id ? "Hide Details" : "View Details"}
                        </Button>

                        {expandedReportId === report.id && (
                          <div className="mt-4 border-t pt-4">
                            <h4 className="text-md font-semibold text-[#1F2937]">Additional Details</h4>
                            <p className="text-gray-600 text-sm">Source: {report.source}</p>
                          </div>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* Saved Locations Tab */}
            {activeTab === "locations" && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-[#1F2937]">Saved Locations</h2>
                  <Button variant="outline" onClick={() => setShowAddLocationModal(true)}>
                    Add New Location
                  </Button>
                </div>

                {locationSuccessMessage && (
                  <div className="p-4 mb-4 bg-green-100 text-green-800 rounded-md">{locationSuccessMessage}</div>
                )}

                {savedLocations.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {savedLocations.map((location) => (
                      <div key={location.id} className="border rounded-md p-4">
                        <h3 className="text-lg font-medium text-[#1F2937]">{location.name}</h3>
                        <p className="text-gray-600 text-sm mb-2">{location.address}</p>
                        <div className="flex justify-between">
                          <div className="space-x-2">
                            <Button variant="outline" size="sm" onClick={() => handleViewOutages(location.id)}>
                              View Outages
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => handleSetAsDefault(location.id)}>
                              Set as Default
                            </Button>
                          </div>
                          <div className="space-x-2">
                            <Button variant="outline" size="sm" onClick={() => handleEditLocation(location.id)}>
                              Edit
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => handleDeleteLocation(location.id)}>
                              Delete
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">
                    No saved locations yet. Add one to quickly check outages in your frequently visited areas.
                  </p>
                )}
              </div>
            )}

            {/* Notification Settings Tab */}
            {activeTab === "notifications" && (
              <div>
                <h2 className="text-xl font-semibold text-[#1F2937] mb-4">Notification Settings</h2>
                <p className="text-gray-600 mb-6">Choose how you want to receive outage notifications.</p>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="font-medium text-[#1F2937]">Browser Notifications</label>
                    <Button
                      variant="outline"
                      className={`px-4 py-2 rounded-md ${
                        notificationSettings.browser
                          ? "bg-[#4F46E5] text-white hover:bg-[#4F46E5]/90"
                          : "border-gray-300 text-gray-700 hover:bg-gray-100"
                      }`}
                      onClick={() => handleToggleNotification("browser")}
                    >
                      {notificationSettings.browser ? "Disable" : "Enable"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="font-medium text-[#1F2937]">WhatsApp Notifications</label>
                    <Button
                      variant="outline"
                      className={`px-4 py-2 rounded-md ${
                        notificationSettings.whatsapp
                          ? "bg-[#4F46E5] text-white hover:bg-[#4F46E5]/90"
                          : "border-gray-300 text-gray-700 hover:bg-gray-100"
                      }`}
                      onClick={() => handleToggleNotification("whatsapp")}
                    >
                      {notificationSettings.whatsapp ? "Disable" : "Enable"}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="font-medium text-[#1F2937]">Email Notifications</label>
                    <Button
                      variant="outline"
                      className={`px-4 py-2 rounded-md ${
                        notificationSettings.email
                          ? "bg-[#4F46E5] text-white hover:bg-[#4F46E5]/90"
                          : "border-gray-300 text-gray-700 hover:bg-gray-100"
                      }`}
                      onClick={() => handleToggleNotification("email")}
                    >
                      {notificationSettings.email ? "Enable" : "Disable"}
                    </Button>
                  </div>
                </div>

                <div className="mt-6">
                  <Button variant="primary" onClick={handleSaveNotificationSettings} disabled={isSubmitting}>
                    {isSubmitting ? "Saving..." : "Save Settings"}
                  </Button>
                </div>
              </div>
            )}

            {/* Account Settings Tab */}
            {activeTab === "account" && (
              <div>
                <h2 className="text-xl font-semibold text-[#1F2937] mb-4">Account Settings</h2>
                <p className="text-gray-600 mb-6">Manage your profile, password, and notification preferences.</p>

                {profileSuccessMessage && (
                  <div className="p-4 mb-4 bg-green-100 text-green-800 rounded-md">{profileSuccessMessage}</div>
                )}

                {/* Profile Information */}
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-[#1F2937] mb-3">Profile Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Name
                      </label>
                      <Input
                        id="name"
                        type="text"
                        defaultValue={user.name}
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        defaultValue={user.email}
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                  </div>
                  <Button variant="primary" className="mt-4" onClick={handleUpdateProfile} disabled={isSubmitting}>
                    {isSubmitting ? "Updating..." : "Update Profile"}
                  </Button>
                </div>

                {/* Change Password */}
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-[#1F2937] mb-3">Change Password</h3>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="currentPassword" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Current Password
                      </label>
                      <Input
                        id="currentPassword"
                        type="password"
                        placeholder="Enter your current password"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                    <div>
                      <label htmlFor="newPassword" className="block text-sm font-medium text-[#1F2937] mb-2">
                        New Password
                      </label>
                      <Input
                        id="newPassword"
                        type="password"
                        placeholder="Enter your new password"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                    <div>
                      <label htmlFor="confirmPassword" className="block text-sm font-medium text-[#1F2937] mb-2">
                        Confirm New Password
                      </label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        placeholder="Confirm your new password"
                        className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                      />
                    </div>
                  </div>
                  <Button variant="primary" className="mt-4" onClick={handleChangePassword} disabled={isSubmitting}>
                    {isSubmitting ? "Changing..." : "Change Password"}
                  </Button>
                </div>

                {/* WhatsApp Number */}
                <div className="mb-6">
                  <h3 className="text-lg font-medium text-[#1F2937] mb-3">WhatsApp Number</h3>
                  {whatsappVerified ? (
                    <div className="flex items-center justify-between">
                      <p className="text-gray-600">Your WhatsApp number is verified.</p>
                      <Button variant="outline" onClick={handleChangeWhatsAppNumber}>
                        Change Number
                      </Button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <p className="text-gray-600">Verify your WhatsApp number to receive notifications.</p>
                      <Button variant="outline" onClick={handleChangeWhatsAppNumber}>
                        Add/Verify Number
                      </Button>
                    </div>
                  )}
                </div>

                {/* Delete Account */}
                <div>
                  <h3 className="text-lg font-medium text-[#1F2937] mb-3">Delete Account</h3>
                  <p className="text-gray-600 mb-4">Permanently delete your account and all associated data.</p>
                  <Button variant="destructive" onClick={handleDeleteAccount}>
                    Delete Account
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Logout Button */}
        <Button variant="secondary" onClick={onLogout}>
          Logout
        </Button>
      </div>

      {/* Add Location Modal */}
      {showAddLocationModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="p-6 border-b">
              <h2 className="text-2xl font-bold text-[#1F2937]">
                {editingLocationId ? "Edit Location" : "Add New Location"}
              </h2>
            </div>
            <form onSubmit={handleAddLocation} className="p-6 space-y-4">
              <div>
                <label htmlFor="locationName" className="block text-sm font-medium text-[#1F2937] mb-2">
                  Location Name
                </label>
                <Input
                  id="locationName"
                  type="text"
                  placeholder="e.g., Home, Office"
                  value={newLocation.name}
                  onChange={(e) => setNewLocation({ ...newLocation, name: e.target.value })}
                  required
                  className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                />
              </div>
              <div>
                <label htmlFor="locationAddress" className="block text-sm font-medium text-[#1F2937] mb-2">
                  Address
                </label>
                <Input
                  id="locationAddress"
                  type="text"
                  placeholder="Enter the address"
                  value={newLocation.address}
                  onChange={(e) => setNewLocation({ ...newLocation, address: e.target.value })}
                  required
                  className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                />
              </div>
              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddLocationModal(false)}
                  className="border-gray-300"
                >
                  Cancel
                </Button>
                <Button type="submit" className="bg-[#4F46E5] hover:bg-[#4F46E5]/90 text-white px-8">
                  {editingLocationId ? "Update Location" : "Add Location"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Location Modal */}
      {showDeleteModal && locationToDelete && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="p-6 border-b">
              <h2 className="text-2xl font-bold text-[#1F2937]">Delete Location</h2>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-gray-600">
                Are you sure you want to delete <strong>{locationToDelete.name}</strong>? This action cannot be undone.
              </p>
              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => setShowDeleteModal(false)}>
                  Cancel
                </Button>
                <Button type="button" variant="destructive" onClick={confirmDeleteLocation}>
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Change WhatsApp Number Modal */}
      {showChangeNumberModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="p-6 border-b">
              <h2 className="text-2xl font-bold text-[#1F2937]">Change WhatsApp Number</h2>
            </div>
            <form onSubmit={handleSubmitNewNumber} className="p-6 space-y-4">
              <div>
                <label htmlFor="newWhatsAppNumber" className="block text-sm font-medium text-[#1F2937] mb-2">
                  New WhatsApp Number
                </label>
                <Input
                  id="newWhatsAppNumber"
                  type="tel"
                  placeholder="Enter your new WhatsApp number"
                  value={newWhatsAppNumber}
                  onChange={(e) => setNewWhatsAppNumber(e.target.value)}
                  required
                  className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                />
                {changeNumberErrors.phone && <p className="text-red-500 text-sm mt-1">{changeNumberErrors.phone}</p>}
              </div>
              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowChangeNumberModal(false)}
                  className="border-gray-300"
                >
                  Cancel
                </Button>
                <Button type="submit" className="bg-[#4F46E5] hover:bg-[#4F46E5]/90 text-white px-8">
                  Submit
                </Button>
              </div>
            </form>

            {otpSuccessMessage && (
              <div className="p-4 mb-4 bg-green-100 text-green-800 rounded-md">{otpSuccessMessage}</div>
            )}
          </div>
        </div>
      )}

      {/* WhatsApp OTP Modal */}
      {showWhatsAppOtp && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
            <div className="p-6 border-b">
              <h2 className="text-2xl font-bold text-[#1F2937]">Verify WhatsApp Number</h2>
              <p className="text-gray-600 mt-1">
                Enter the 6-digit OTP sent to <strong>{newWhatsAppNumber}</strong>
              </p>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label htmlFor="whatsappOtp" className="block text-sm font-medium text-[#1F2937] mb-2">
                  WhatsApp OTP
                </label>
                <Input
                  id="whatsappOtp"
                  type="text"
                  placeholder="Enter OTP"
                  value={whatsappOtp}
                  onChange={(e) => {
                    setWhatsappOtp(e.target.value)
                    setChangeNumberErrors({ ...changeNumberErrors, whatsappOtp: "" })
                  }}
                  maxLength="6"
                  className="h-12 border-2 border-gray-300 focus:border-[#4F46E5] focus:ring-0 outline-none"
                />
                {changeNumberErrors.whatsappOtp && (
                  <p className="text-red-500 text-sm mt-1">{changeNumberErrors.whatsappOtp}</p>
                )}
              </div>
              <div className="flex items-center justify-between">
                <Button variant="link" disabled={resendTimer > 0 || isVerifyingWhatsApp} onClick={resendWhatsAppOtp}>
                  {resendTimer > 0 ? `Resend OTP in ${resendTimer}s` : "Resend OTP"}
                </Button>
                <Button variant="primary" onClick={verifyWhatsAppOtp} disabled={isVerifyingWhatsApp}>
                  {isVerifyingWhatsApp ? "Verifying..." : "Verify OTP"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
